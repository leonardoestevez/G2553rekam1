//******************************************************************************
//   MSP430G2xx3 Demo - USCI_A0, 115200 UART Echo ISR, DCO SMCLK, LPM4
//
//   Description: Echo a received character, RX ISR used. Normal mode is LPM4.
//   Automatic clock activation for SMCLK through the USCI is demonstrated.
//   All I/O configured as low outputs to eliminate floating inputs.
//   USCI_A0 RX interrupt triggers TX Echo.
//   Baud rate divider with 1MHz = 1MHz/115200 = ~8.7
//   ACLK = n/a, MCLK = SMCLK = CALxxx_1MHZ = 1MHz
//
//                MSP430G2xx3
//             -----------------
//         /|\|              XIN|-
//          | |                 |
//          --|RST          XOUT|-
//            |                 |
//            |             P1.4|-->SMCLK = 1MHz (active on demand)
//            |                 |
//            |     P1.2/UCA0TXD|------------>
//            |                 | 115200 - 8N1
//            |     P1.1/UCA0RXD|<------------
//
//   D. Dang
//   Texas Instruments Inc.
//   February 2011
//   Built with CCS Version 4.2.0 and IAR Embedded Workbench Version: 5.10
//******************************************************************************
#include "msp430g2553.h"
#include "HAL_Setup.h"
#include "BlueRadios_BLE.h"
#include "stdlib.h"
#include "string.h"

unsigned int Time = 0;
unsigned int Rate = 0; //The rate of characters transmitted per second
//long value = 0;
#define     LED1                  BIT0
#define     LED2                  BIT6
#define     LED_DIR               P1DIR
#define     LED_OUT               P1OUT

#define     BUTTON                BIT3
#define     BUTTON_OUT            P1OUT
#define     BUTTON_DIR            P1DIR
#define     BUTTON_IN             P1IN
#define     BUTTON_IE             P1IE
#define     BUTTON_IES            P1IES
#define     BUTTON_IFG            P1IFG
#define     BUTTON_REN            P1REN

#define     TIMER_PWM_MODE        0
#define     TIMER_PWM_PERIOD      2000
#define     TIMER_PWM_OFFSET      20

unsigned char timerMode = TIMER_PWM_MODE;

/* reverse:  reverse string s in place */
 void reverse(char s[])
 {
     int i, j;
     char c;

     for (i = 0, j = strlen(s)-1; i<j; i++, j--) {
         c = s[i];
         s[i] = s[j];
         s[j] = c;
     }
 }

/* itoa:  convert n to characters in s */
 void itoa(int n, char s[])
 {
     int i, sign;

     if ((sign = n) < 0)  /* record sign */
         n = -n;          /* make n positive */
     i = 0;
     do {       /* generate digits in reverse order */
         s[i++] = n % 10 + '0';   /* get next digit */
     } while ((n /= 10) > 0);     /* delete it */
     if (sign < 0)
         s[i++] = '-';
//     s[i] = '\n';
     s[i] = '\0';
//     s[i] = '\0';
     reverse(s);
 }

//Function Definitions
/*
void ADD(int *n, int m, int *p, int q) {
	n[0] = p[0]+q;
}
void SUB(int *n, int m, int *p, int q) {
	n[0]= p[0]-q;
}
void MPY(int *n, int m, int *p, int q) {
	n[0]=p[0]*q;
}
*/
char message[10];
int executor=1;

void AND(int *n, int *m, int *p, int *q) {
	p[0]=n[0] & m[0];
}

void OR(int *n, int *m, int *p, int *q) {
	p[0]=n[0] | m[0];
}

void NOT(int *n, int *m, int *p, int *q) {
	p[0]=!m[0];
}

void SET(int *n, int *m, int *p, int *q) {
	n[0]=m[0];
}

void GET(int *n, int *m, int *p, int *q) {
    char tx_string[7];
    int j;
    if(m[0]==11){
    	putnUART(message, 10);
    }else if(m[0]==7 || m[0]==6){
    	for(j=0;j<10;j++){
			itoa(q[j], tx_string);
			putnUART(tx_string, strlen(tx_string));
    	}

    }else{
		itoa(n[0], tx_string);
		putnUART(tx_string, strlen(tx_string));
    }
	putnUART("\n\r",2);
}
void GEN(int *n, int *m, int *p, int *q) {
    char tx_string[2];
    tx_string[0]=n[0]>>8;
    tx_string[1]=n[0];
	putnUART(tx_string, 2);
}
void ENDIF(int *n, int *m, int *p, int *q) {
	n[0]=p[0];
}

void IFEQ(int *n, int *m, int *p, int *q) {
	if(n[0]==m[0]){
		if(p[0]==1000){
			p[0]=0;
		}else{
			p[0]=1;
		}
	}
}
void IFGT(int *n, int *m, int *p, int *q) {
	if(n[0]>m[0]){
		if(p[0]==1000){
			p[0]=0;
		}else{
			p[0]=1;
		}
	}
}

void IFLT(int *n, int *m, int *p, int *q) {
	if(n[0]<m[0]){
		if(p[0]==1000){
			p[0]=0;
		}else{
			p[0]=1;
		}
	}
}

void MAC(int *n, int *m, int *p, int *q) {
	n[0]=0;
	int ii;
	for(ii=0;ii<10;ii++){
		n[0]=n[0]+(m[ii]*p[ii]);
	}
	n[0]=n[0]/q[0];
}

int sleepcounter=0;

void SLEEPY(int *n, int *m, int *p, int *q) {
	int ii;
	for(ii=0;ii<m[0];ii++){
	_delay_cycles(32000);}
//	sleepcounter=m[0];
//	executor=0;
}

void InitializeButton(void)                 // Configure Push Button
{
  BUTTON_DIR &= ~BUTTON;
  BUTTON_OUT |= BUTTON;
  BUTTON_REN |= BUTTON;
  BUTTON_IES |= BUTTON;
  BUTTON_IFG &= ~BUTTON;
  BUTTON_IE |= BUTTON;
}

void ConfigureAdc(void) {   /* Configure ADC  Channel */
ADC10CTL1 = INCH_5 + ADC10DIV_3 ;      // Channel 5, ADC10CLK/4
ADC10CTL0 = SREF_0 + ADC10SHT_3 + ADC10ON + ADC10IE;  //Vcc & Vss as reference
ADC10AE0 |= BIT5;                         //P1.5 ADC option     }
}

void ConfigureTimerPwm(void)
{
  //timerMode = TIMER_PWM_MODE;

  TA0CCR0 = 3200;                              //
  TA0CTL = TASSEL_2 + MC_1;                  // TACLK = SMCLK, Up mode.
  TA0CCTL0 = 0x10;
//  TACCTL1 = CCIE + OUTMOD_3;                // TACCTL1 Capture Compare
//  TACCR1 = 1;
}

unsigned int quiet = 0;
unsigned int event = 0;
int a2dbuffersize=10;
int a2dbuffer1[10];
int a2dbuffer2[10];
int bufferindex=0;
int a2devent1=0;
int a2devent2=1;
int pulse[2]={0,0};
int pulsecount=0;
int a2dperiod=1;
int a2dcounter=0;
int pinmux[21] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 13, 13, 13, 13, 13, 13, 14};
//int sleepcount[21];
int learn=0;
int lastsleepcounter;



void main(void)
 {
    int ii;
    int kk;
    char buff[21];
    char buff1[2];
    char buff2[6];
//    char tx_string[13];
    char pin_string[4];
//    char buff4[6];

    extern unsigned char LineBuffer[21];


    int buffer6[10] = {0,0,0,0,0,0,0,0,0,0};
    int buffer10[10];
    int buffer6size=0;
//    int buffer10size=0;


    int state[20];
    int numberofstatements=1;
    int value[20][1];
    int tempvalue[1];
    unsigned int symbolindex[20][2];
    unsigned int statementnumber=1;
    unsigned int statementnumb;


    int symbol[21] = {0, 0, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

    void (*functionPtrArray[10])( int*, int*, int*, int* );


    symbol[0]=1000;
    symbol[1]=1000;
    symbol[12]=1;
    P2DIR |= BIT3;
    LED_DIR |= LED1 + LED2 + BIT4;
    LED_OUT &= ~(LED1 + LED2 + BIT4);


	WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT

  HAL_Clock_Setup();
  HAL_Port_Setup();
  InitUART();
  InitializeButton();
  ConfigureTimerPwm();

//  WDTCTL = WDT_MDLY_32;                 // 2ms interval
//  IE1 |= WDTIE;                             // Enable WDT interrupt

//Confiugure ADC

//  BCSCTL1 = CALBC1_1MHZ;                    // Set range   DCOCTL = CALDCO_1MHZ;
//  BCSCTL2 &= ~(DIVS_3);                  // SMCLK = DCO = 1MHz
  P1DIR |= LED1 + LED2;
  P1SEL |= BIT5;                             //ADC Input pin P1.5
  P1OUT &= ~(LED1 + LED2);
  ConfigureAdc();
  //__enable_interrupt();                     // Enable interrupts.


  __bis_SR_register(GIE);       // Enter LPM4, interrupts enabled

//BLERadio_Init();
//symbol[11]=-11111;
//Interpreter - this translates a number of single line statements into an array of symbols, values, and function codes that can
//be quickly executed. Additional lines for a given state may be received and interpreted and will supersede any previous lines.
// Symbol with index 0 is reserved for STATE, Symbols 1-20 are reserved for relevant pins(as PIO or ADC)
// This will become the Rx Service Handler - whenever a command line is received, it will either be executed or stored
// depending on whether the executor is running (executor running = execute, executor stopped = store)

while(1){


//	pulse[0] = symbol[2];
//	pulse[1] = symbol[17];
	  //Events
	  symbol[5]=event;

	  //Simple ms timer
	  symbol[8]++;
	  if(symbol[8]>8000){
		  symbol[8]=0;
		  //Simple second timer
		  symbol[9]++;
	  }
/*		if(sleepcounter==1){
			sleepcounter = 0;
			if(!quiet){
			putnUART("\n\rOK\n\r", 6);}
		}*/
		//PWM Output
        ii=0;
		for(kk=2;kk<20;kk++){
			if(pinmux[kk]==2){
				pulse[ii]=symbol[kk];
				ii++;
			}
		}
		 //Executor - this uses the arrays of interpreted statements to execute C functions for a given state
		 //The executor will sleep until an event is triggered (Rx, new acquisition, change in pin state, etc.)
		 	if((executor)&&(a2devent1||a2devent2)){
		 		for(statementnumb=1;statementnumb<numberofstatements;statementnumb++){
		 			if((state[statementnumb]==symbol[0])){
		 				if(value[statementnumb][0]==12){
		 					if(symbolindex[statementnumb][0]==7){
		 						if(a2devent1){
		 							(*functionPtrArray[statementnumb])(&symbol[symbolindex[statementnumb][1]], &a2dbuffer1[0], &buffer6[0], &symbol[12]);
		 		//					a2devent1=0;
		 						}else{
		 							(*functionPtrArray[statementnumb])(&symbol[symbolindex[statementnumb][1]], &a2dbuffer2[0], &buffer6[0], &symbol[12]);
		 		//					a2devent2=0;
		 						}
		 					}
		 				}else{
	 						if(a2devent1){
	 							(*functionPtrArray[statementnumb])(&symbol[symbolindex[statementnumb][0]], &value[statementnumb][0], &symbol[symbolindex[statementnumb][1]], &a2dbuffer1[0]);
	 							a2devent1=0;
	 						}else{
	 							(*functionPtrArray[statementnumb])(&symbol[symbolindex[statementnumb][0]], &value[statementnumb][0], &symbol[symbolindex[statementnumb][1]], &a2dbuffer2[0]);
	 							a2devent2=0;
	 						}
		 				}
						if(symbolindex[statementnumb][0]==5){
							event=0;
						}
		 				//PWM Output
		 				ii=0;
						for(kk=2;kk<20;kk++){
							if(pinmux[kk]==2){
								pulse[ii]=symbol[kk];
								ii++;
							}
						}
		 			}
		 		}
		 	}

	   //update output state of pins based on symbol table and PIO configuration

	  //BLE Interpreter
	if(bUARTDataReceived_event){
		bUARTDataReceived_event=0;
		for(ii=0;ii<20;ii++){
			buff[ii]=LineBuffer[ii];
		}


//See if this Statement is declaring a State for subsequent statements and change state if so.
	if(!strncmp(buff,"move",4)){
		for(ii=0;ii<3;ii++){
			buff1[ii]=buff[ii+5];
		}
		for(ii=0;ii<6;ii++){
			buff2[ii]=buff[ii+7];
		}
		pinmux[atoi(buff2)] = pinmux[atoi(buff1)];
		if(!quiet){
		putnUART("\n\rOK\n\r", 6);}

	}
    if(!strncmp(buff,"endif",5)){
    	if(executor){
    		ENDIF(&symbol[0], 0, &symbol[1], 0);
    		state[statementnumber]=1000;
    		if(!quiet){
    		putnUART("\n\rOK\n\r", 6);}
    	}else{
    		state[statementnumber]=symbol[0];
			symbolindex[statementnumber][0] = 0;
			symbolindex[statementnumber][1] = 1;
			symbol[0]=symbol[1];
    		functionPtrArray[statementnumber] = ENDIF;
    		statementnumber++;
    		numberofstatements++;
    		if(!quiet){
    		putnUART("\n\rOK\n\r", 6);}
    	}
    }
    if(!strncmp(buff,"learn",5)){
    	learn=1;
       	executor=0;
       	sleepcounter=0;
       	lastsleepcounter=0;
        	if(!quiet){
        	    		putnUART("\n\rOK\n\r", 6);}
    }
    if(!strncmp(buff,"sleep",5)){
		for(ii=0;ii<3;ii++){
			buff1[ii]=buff[ii+6];
		}
    	for(ii=0;ii<6;ii++){
			buff2[ii]=buff[ii+8];
		}
		tempvalue[0]=atoi(buff2);
		if(executor){
			SLEEPY(&symbol[0], &tempvalue[0], &symbol[1], 0);
			if(!quiet){
			putnUART("\n\rOK\n\r", 6);}
	//    	putnUART("+++\r\n", 5);
	//    	putnUART("ATSP,2,0,0\r\n", 12);
	//    	putnUART("ATZ\r\n", 5);
	   	}else{
	    		state[statementnumber]=symbol[0];
	    		value[statementnumber][0]=tempvalue[0];
				symbolindex[statementnumber][0] = atoi(buff1);
				symbolindex[statementnumber][1] = atoi(buff2);
	    		functionPtrArray[statementnumber] = SLEEPY;
	    		statementnumber++;
	    		numberofstatements++;
	    		if(!quiet){
	    		putnUART("\n\rOK\n\r", 6);}
	    	}
    }

    if(!strncmp(buff,"and",3)){
		for(ii=0;ii<3;ii++){
			buff1[ii]=buff[ii+3];
		}
		for(ii=0;ii<6;ii++){
			buff2[ii]=buff[ii+5];
		}
		if(executor){
				AND(&symbol[atoi(buff2)], &symbol[atoi(buff1)], &symbol[20], &symbol[12]);
				if(!quiet){
				putnUART("\n\rOK\n\r", 6);}
    	}else{
    		state[statementnumber]=symbol[0];
			symbolindex[statementnumber][0] = atoi(buff1);
			symbolindex[statementnumber][1] = atoi(buff2);
			value[statementnumber][0] = 20;
    		functionPtrArray[statementnumber] = AND;
    		statementnumber++;
    		numberofstatements++;
    		if(!quiet){
    		putnUART("\n\rOK\n\r", 6);}
    	}
    }
    if(!strncmp(buff,"not",3)){
		for(ii=0;ii<3;ii++){
			buff1[ii]=buff[ii+3];
		}
		for(ii=0;ii<6;ii++){
			buff2[ii]=buff[ii+5];
		}
		if(executor){
				NOT(&symbol[atoi(buff2)], &symbol[atoi(buff1)], &symbol[20], &symbol[12]);
				if(!quiet){
				putnUART("\n\rOK\n\r", 6);}
    	}else{
    		state[statementnumber]=symbol[0];
			symbolindex[statementnumber][0] = atoi(buff1);
			symbolindex[statementnumber][1] = atoi(buff2);
			value[statementnumber][0] = 20;
    		functionPtrArray[statementnumber] = NOT;
    		statementnumber++;
    		numberofstatements++;
    		if(!quiet){
    		putnUART("\n\rOK\n\r", 6);}
    	}
    }
    if(!strncmp(buff,"or",2)){
		for(ii=0;ii<3;ii++){
			buff1[ii]=buff[ii+2];
		}
		for(ii=0;ii<6;ii++){
			buff2[ii]=buff[ii+4];
		}
		if(executor){
				OR(&symbol[atoi(buff2)], &symbol[atoi(buff1)], &symbol[20], &symbol[12]);
				if(!quiet){
				putnUART("\n\rOK\n\r", 6);}
    	}else{
    		state[statementnumber]=symbol[0];
			symbolindex[statementnumber][0] = atoi(buff1);
			symbolindex[statementnumber][1] = atoi(buff2);
			value[statementnumber][0] = 20;
    		functionPtrArray[statementnumber] = OR;
    		statementnumber++;
    		numberofstatements++;
    		if(!quiet){
    		putnUART("\n\rOK\n\r", 6);}
    	}
    }
    if(!strncmp(buff,"mac",3)){
		for(ii=0;ii<3;ii++){
			buff1[ii]=buff[ii+3];
		}
		for(ii=0;ii<6;ii++){
			buff2[ii]=buff[ii+5];
		}
		if(executor){
				if(atoi(buff1)==7){
//fix					MAC(&symbol[atoi(buff2)], &buffer6[0], &a2dbuffer[0], &symbol[12]);
//fix					a2devent=0;
//fix					bufferindex=0;
				}else if(atoi(buff1)==10){
					MAC(&symbol[atoi(buff2)], &buffer6[0], &buffer10[0], &symbol[12]);
				}
				if(!quiet){
				putnUART("\n\rOK\n\r", 6);}
    	}else{
    		state[statementnumber]=symbol[0];
			symbolindex[statementnumber][0] = atoi(buff1);
			symbolindex[statementnumber][1] = atoi(buff2);
			value[statementnumber][0] = 12;
    		functionPtrArray[statementnumber] = MAC;
    		statementnumber++;
    		numberofstatements++;
    		if(!quiet){
    		putnUART("\n\rOK\n\r", 6);}
    	}
    }
    if(!strncmp(buff,"do",2)){
    	learn=0;
    	executor=1;
    	symbol[0]=1000;
    	if(!quiet){
    	putnUART("\n\rOK\n\r", 6);}
    }
    if(!strncmp(buff,"quiet",5)){
    	quiet=1;
    }
    if(!strncmp(buff,"talk",4)){
    	quiet=0;
    }
    if(!strncmp(buff,"read",4)){
    	executor=0;
//    	state[statementnumber]=1000;
//    	statementnumber=1;
//    	numberofstatements=1;
    	if(!quiet){
    	    		putnUART("\n\rOK\n\r", 6);}
    }

    if(!strncmp(buff,"?",1)){
    	for(kk=0;kk<21;kk++){
    		putnUART("\nPIN ",4);
    		itoa(kk, pin_string);
    		putnUART(pin_string, 2);
    		switch(pinmux[kk]){
				case 0:
					putnUART(" CURRENT STATE\r", 15);
					break;
				case 1:
					putnUART(" PREVIOUS STATE-VCC\r", 20);
				break;
				case 2:
					putnUART(" PULSED OUTPUT\r", 15);
				break;
				case 3:
					putnUART(" UART Tx (BT)\r", 14);
				break;
				case 4:
					putnUART(" UART Rx (BT)\r", 14);
				break;
				case 5:
					putnUART(" INPUT EVENT(BUTTON)\r", 21);
					break;
				case 6:
					putnUART(" MAC BUFFER\r", 12);
				break;
				case 7:
					putnUART(" ANALOG INPUT\r", 14);
				break;
				case 8:
					putnUART(" MIILISEC TIMER\r", 16);
				break;
				case 9:
					putnUART(" SECOND TIMER\r", 14);
				break;
				case 10:
					putnUART(" BUFFER-GND\r", 12);
				break;
				case 11:
					putnUART(" MESSAGE\r", 9);
				break;
				case 12:
					putnUART(" MAC DIVISOR\r", 13);
				break;
				case 13:
					putnUART(" SYMBOL\r", 8);
				break;
				case 14:
					putnUART(" LOGIC OUT\r", 11);
				break;
    		}
    	}
/*    	putnUART("\nPIN 0 CURRENT STATE\r", 21);
    	putnUART("\nPIN 1 PREVIOUS STATE-VCC\r", 26);
    	putnUART("\nPIN 2 PULSED OUTPUT\r", 21);
    	putnUART("\nPIN 3 UART Tx (BT)\r", 20);
    	putnUART("\nPIN 4 UART Rx (BT)\r", 20);
    	putnUART("\nPIN 5 EVENT(BUTTON)\r", 21);
    	putnUART("\nPIN 6 MAC BUFFER\r", 18);
    	putnUART("\nPIN 7 ANALOG INPUT\r", 20);
    	putnUART("\nPIN 8 MIILISEC TIMER\r", 22);
    	putnUART("\nPIN 9 SECOND TIMER\r", 20);
    	putnUART("\nPIN 10 BUFFER-GND\r", 19);
    	putnUART("\nPIN 11 MESSAGE\r", 16);
    	putnUART("\nPIN 12 MAC DIVISOR\r", 20);
    	putnUART("\nPIN 13 SYMBOL\r", 15);
    	putnUART("\nPIN 14 SYMBOL\r", 15);
    	putnUART("\nPIN 15 SYMBOL\r", 15);
    	putnUART("\nPIN 16 SYMBOL\r", 15);
    	putnUART("\nPIN 17 PULSED OUTPUT\r", 22);
    	putnUART("\nPIN 18 NO CONNECT\r", 19);
    	putnUART("\nPIN 19 NO CONNECT\r", 19);
    	putnUART("\nPIN 20 LOGIC OUT\r", 20);*/
    	putnUART("\nJ1.1 = PIN1\r", 13);
    	putnUART("\nJ2.1 = PIN11\r", 14);
    	putnUART("\nmodes: read write learn do quiet sleep move\noperators: get put ifg/l/e endif mac or and\r\n", 90);
    }

    if(!strncmp(buff,"get",3)){
		for(ii=0;ii<3;ii++){
			buff1[ii]=buff[ii+3];
		}
		for(ii=0;ii<6;ii++){
			buff2[ii]=buff[ii+5];
		}
		tempvalue[0]=atoi(buff1);
		if(tempvalue[0]==7){
//fix			a2devent=0;
//fix			bufferindex=0;
		}
		if(executor){
			if(tempvalue[0]==6){
				GET(&symbol[atoi(buff1)], &tempvalue[0], &symbol[0], &buffer6[0]);
			}else{
				if(a2devent1){
					GET(&symbol[atoi(buff1)], &tempvalue[0], &symbol[0], &a2dbuffer1[0]);
					a2devent1=0;
				}else{
					GET(&symbol[atoi(buff1)], &tempvalue[0], &symbol[0], &a2dbuffer2[0]);
					a2devent2=0;
				}
//			GET(&symbol[atoi(buff1)], &tempvalue[0], &symbol[0], &a2dbuffer1[0]);
//			GET(&symbol[atoi(buff1)], &tempvalue[0], &symbol[0], &a2dbuffer2[0]);
			}
			if(atoi(buff1)==5){
				event=0;
			}
			state[statementnumber]=1000;
		}else{
			functionPtrArray[statementnumber] = GET;
			state[statementnumber]=symbol[0];
			symbolindex[statementnumber][0] = atoi(buff1);
			value[statementnumber][0] = tempvalue[0];
//			symbolindex[statementnumber][1]=a2dbuffer[0];
			statementnumber++;
			numberofstatements++;
			if(!quiet){
			    		putnUART("\n\rOK\n\r", 6);}
		}
    }

    if(!strncmp(buff,"gra",3)){
		for(ii=0;ii<3;ii++){
			buff1[ii]=buff[ii+3];
		}
		if(executor){
//			tempvalue[0]=atoi(buff2);
			GEN(&symbol[atoi(buff1)], &tempvalue[0], &symbol[0], 0);
			state[statementnumber]=1000;
		}
    }

//See if this statement is setting the value of a symbol for execution and load this setting for execution within the current state.
    if(!strncmp(buff,"put",3)){
		for(ii=0;ii<3;ii++){
			buff1[ii]=buff[ii+4];
		}
		for(ii=0;ii<6;ii++){
			buff2[ii]=buff[ii+6];
		}
		tempvalue[0]=atoi(buff2);
		if(executor){
			if(atoi(buff1)==11){
				for(ii=0;ii<10;ii++){
					message[ii]=buff[ii+6];
				}
			}else if(atoi(buff1)==6){
				buffer6size=buffer6size+1;
				for(ii=buffer6size;ii>-1;ii--){
					buffer6[ii+1]=buffer6[ii];
				}
				buffer6[0]=tempvalue[0];
			}else if(atoi(buff1)==7){
				a2dperiod = tempvalue[0];
			}else{
				SET(&symbol[atoi(buff1)], &tempvalue[0], &symbol[0], &a2dbuffer1[0]);
			}
			if(!quiet){
			    		putnUART("\n\rOK\n\r", 6);}
		}else{
			if(learn){
	    		state[statementnumber]=symbol[0];
	    		value[statementnumber][0]=sleepcounter-lastsleepcounter;
				symbolindex[statementnumber][0] = atoi(buff1);
				symbolindex[statementnumber][1] = atoi(buff2);
	    		functionPtrArray[statementnumber] = SLEEPY;
	    		statementnumber++;
	    		numberofstatements++;
	    		lastsleepcounter=sleepcounter;
	    		SET(&symbol[atoi(buff1)], &tempvalue[0], &symbol[0], &a2dbuffer1[0]);
			}
			functionPtrArray[statementnumber] = SET;
			state[statementnumber]=symbol[0];
			symbolindex[statementnumber][0] = atoi(buff1);
			value[statementnumber][0] = atoi(buff2);
			statementnumber++;
			numberofstatements++;

			if(!quiet){
			    		putnUART("\n\rOK\n\r", 6);}
		}
    }

//See if this statement is a condition(=,>,<) and load this condition for execution within the current state.

    if(!strncmp(buff,"if",2)){
		for(ii=0;ii<3;ii++){
			buff1[ii]=buff[ii+4];
		}
		for(ii=0;ii<6;ii++){
			buff2[ii]=buff[ii+6];
		}
		if(executor){
			tempvalue[0]=atoi(buff2);
			if(!strncmp(buff,"ife",3)){
				IFEQ(&symbol[atoi(buff1)], &tempvalue[0], &symbol[atoi(buff1)], &a2dbuffer1[0]);
			}
			if(!strncmp(buff,"ifg",3)){
				IFGT(&symbol[atoi(buff1)], &tempvalue[0], &symbol[atoi(buff1)], &a2dbuffer1[0]);
			}
			if(!strncmp(buff,"ifl",3)){
				IFLT(&symbol[atoi(buff1)], &tempvalue[0], &symbol[atoi(buff1)], &a2dbuffer1[0]);
			}
			if(!quiet){
			    		putnUART("\n\rOK\n\r", 6);}
		}else{
			state[statementnumber]=symbol[0];
// Set Execution state to 0 or 1
				if(symbol[0]>10){
					symbol[1]=1000;
					symbol[0]=0;
				}else{
					symbol[1]=1000;
					symbol[0]=1;
				}
			value[statementnumber][0]=atoi(buff2);
			symbolindex[statementnumber][1] = 0;
			symbolindex[statementnumber][0] = atoi(buff1);
//			value[statementnumber][1]=atoi(buff4);
			if(!strncmp(buff,"ife",3)){
				functionPtrArray[statementnumber] = IFEQ;
			}
			if(!strncmp(buff,"ifg",3)){
				functionPtrArray[statementnumber] = IFGT;
			}
			if(!strncmp(buff,"ifl",3)){
				functionPtrArray[statementnumber] = IFLT;
			}
			statementnumber++;
			numberofstatements++;
			if(!quiet){
			    		putnUART("\n\rOK\n\r", 6);}
		}
    }

	}
}
//  __bis_SR_register(LPM4_bits + GIE);       // Enter LPM4, interrupts enabled
}

#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer0_A0(void)
{
int ii;
  //ADC Conversion
	 ADC10CTL0 |= ENC + ADC10SC;             // Sampling and conversion start
//	 __bis_SR_register(CPUOFF + GIE);        // LPM0 with interrupts enabled
	pulsecount++;
	for(ii=0;ii<2;ii++){
		if(pulsecount>pulse[0]){
			LED_OUT |= LED1;
		}else{
			LED_OUT &= ~LED1;
		}
		if(pulsecount>pulse[1]){
			LED_OUT |= LED2;
		}else{
			LED_OUT &= ~LED2;
		}
	}
	 if(pulsecount>100){
		 pulsecount=0;
		 sleepcounter++;
	 }

  a2dcounter++;
  if(a2dcounter>=a2dperiod){
	  a2dcounter=0;
	 if(!a2devent1 && a2devent2){
		 a2dbuffer1[bufferindex]=ADC10MEM;
		 bufferindex= bufferindex+1;
		 if(bufferindex>=a2dbuffersize){
			 bufferindex=0;
			 a2devent1=1;
			 a2devent2=0;
		 }
	 }else if(!a2devent2){
		 a2dbuffer2[bufferindex]=ADC10MEM;
		 bufferindex= bufferindex+1;
		 if(bufferindex>=a2dbuffersize){
			 bufferindex=0;
			 a2devent2=1;
		 }
	 }
	   }
}

//Push Button ISR
#pragma vector=PORT1_VECTOR
__interrupt void PORT1_ISR(void)
{
  BUTTON_IFG = 0;
  BUTTON_IE &= ~BUTTON;
  WDTCTL = WDT_ADLY_250;
  IFG1 &= ~WDTIFG;
  IE1 |= WDTIE;
	 __delay_cycles(100000);
  BUTTON_IE |= BUTTON;
  event = 1;
}

// ADC10 interrupt service routine
#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR (void) {
	__bic_SR_register_on_exit(CPUOFF);        // Return to active mode }
}



// Watchdog Timer interrupt service routine
#pragma vector=WDT_VECTOR
__interrupt void watchdog_timer(void)
{
  P2OUT ^= BIT2;
  Time += 2;  // add 2 ms to the timer counter
  if(Time >= 1000)
  {
      Rate = Byte_Counter;
      Byte_Counter = 0;
      Time = 0;
  }
}
