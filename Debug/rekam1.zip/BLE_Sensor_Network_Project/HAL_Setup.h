/*
 * HAL_Setup.h
 *
 *  Created on: Jul 13, 2012
 *      Author: a0273379
 */

#ifndef HAL_SETUP_H_
#define HAL_SETUP_H_


void HAL_Port_Setup(void);
void HAL_Clock_Setup(void);


#endif /* HAL_SETUP_H_ */
